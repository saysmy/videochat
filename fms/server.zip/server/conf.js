var ServerURL = 'http://www.eccbuy.net/index.php?r=amf';
var mid = 1;//主播ID